<?php

/** @var yii\web\View $this */
/** @var yii\bootstrap5\ActiveForm $form */
/** @var app\models\ContactForm $model */

use yii\bootstrap5\ActiveForm;
use yii\bootstrap5\Html;
use yii\captcha\Captcha;


?>
<div style="margin-top:50px" class="site-contact d-flex justify-content-between">
    <div class="kart"><img src="../images/карта.png" alt=""></div>
<div class="contact"><h2>Курган</h2>
<h2>Улица Коли мяготина 96</h2>
<h2>+7-912-575-12-34</h2>
<h2>Nightwhite@email.ru</h2>
</div>

</div>
