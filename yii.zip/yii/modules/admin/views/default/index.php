<div class="admin-default-index">
    <h1>Панель Администратора</h1>
</div>
